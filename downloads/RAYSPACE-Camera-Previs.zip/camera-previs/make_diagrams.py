from PIL import Image,ImageDraw,ImageFont
import json,math
P='/workspace/camera-previs/'
F='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font=lambda n:ImageFont.truetype(F,n)
f16=font(16);f20=font(20);f13=font(13)
data=json.load(open(P+'camera-path.json'))['frames']
stages=[(0,1.3,'01  高空俯冲'),(1.3,2.5,'02  侧面跟拍'),(2.5,4.1,'03  绕前推近'),(4.1,5.7,'04  鞋部低拍'),(5.7,7.8,'05  升高俯拍'),(7.8,10.2,'06  回到正面'),(10.2,12.4,'07  拉至全身'),(12.4,15.3,'08  拉远升空')]
colors=['#72d7ed','#a4db99','#f5ca78','#f6938c','#b8a5fa','#f6a4d0','#8ee1be','#7caeff']
def xy(v):return(180+v[0]*5.1,200-v[1]*5.1)
for n,fr in enumerate(data):
 im=Image.new('RGB',(360,640),'#101820');d=ImageDraw.Draw(im)
 t=fr['time_s'];idx=next(i for i,(a,b,_) in enumerate(stages) if a<=t<b)
 d.text((22,16),stages[idx][2],font=f20,fill=colors[idx]);d.text((22,49),f'{t:05.2f} / 15.21 秒',font=f16,fill='#c5d2dd')
 d.rounded_rectangle((12,87,348,450),12,fill='#17232e')
 d.text((24,99),'相机轨迹 · 俯视',font=f16,fill='white')
 d.rectangle((113,125,247,445),fill='#26323b')
 for y in range(178,228,6):d.rectangle((119,y,241,y+2),fill='#83909a')
 for a in [35,270]:
  for y in [135,202,269,367]:d.rectangle((a,y,a+48,y+52),fill='#3b4650',outline='#53616b')
 for j in range(1,len(data),2):
  st=next(i for i,(a,b,_) in enumerate(stages) if a<=data[j]['time_s']<b)
  d.line([xy(data[j-1]['camera_xyz']),xy(data[j]['camera_xyz'])],fill=colors[st],width=2)
 cx,cy=xy(fr['camera_xyz']);tx,ty=xy(fr['target_xyz'])
 d.line([(cx,cy),(tx,ty)],fill='#e4eef3',width=1)
 ang=math.atan2(ty-cy,tx-cx)
 for delta in [-.4,.4]:d.line([(cx,cy),(cx+26*math.cos(ang+delta),cy+26*math.sin(ang+delta))],fill='#ffe49c',width=2)
 d.ellipse((tx-4,ty-4,tx+4,ty+4),fill='#f13755');d.ellipse((cx-5,cy-5,cx+5,cy+5),fill='#ffe49c')
 d.text((22,463),'● 相机     ● 红帽人物',font=f16,fill='#cfdae3')
 d.rectangle((24,506,336,517),fill='#293d4d');d.rectangle((24,506,24+312*min(1,fr['camera_xyz'][2]/65),517),fill=colors[idx])
 d.text((22,533),f"相机高度：{fr['camera_xyz'][2]:.1f} m（估计）",font=f16,fill='#e5ecf1')
 d.text((22,565),'简化三维预演 / 非精确追踪',font=f16,fill='#c3cdd5');d.text((22,595),'Higgsfield 尚未连接',font=f13,fill='#97a9b8')
 im.save(P+f'diagram/{n+1:04d}.png')
bar=Image.new('RGB',(1080,48),'#0b1118');d=ImageDraw.Draw(bar)
for x,text in [(16,'原片参考'),(376,'三维模型预演'),(736,'相机位置 / 高度')]:d.text((x,10),text,font=f20,fill='#edf3f8')
bar.save(P+'banner.png')
