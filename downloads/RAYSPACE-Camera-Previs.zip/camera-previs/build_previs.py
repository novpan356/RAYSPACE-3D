import bpy, math, json, os
from mathutils import Vector
OUT='/workspace/camera-previs'
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
s=bpy.context.scene
s.render.engine='BLENDER_WORKBENCH'
s.render.resolution_x=360; s.render.resolution_y=640; s.render.resolution_percentage=100
s.render.fps=24; s.frame_start=1; s.frame_end=365
s.display.shading.light='STUDIO'; s.display.shading.studiolight_rotate_z=0.4
s.display.shading.color_type='MATERIAL'; s.display.shading.show_shadows=True
s.display.shading.show_cavity=True; s.display.shading.cavity_type='BOTH'
s.display.shading.background_type='WORLD'; s.world.color=(0.16,0.19,0.23)
s.view_settings.view_transform='Standard'
def mat(name,col):
 m=bpy.data.materials.new(name); m.diffuse_color=(*col,1); return m
road=mat('Asphalt',(0.13,.16,.19)); white=mat('Crosswalk',(.88,.87,.8)); stone=mat('Limestone',(.53,.50,.43)); glass=mat('Windows',(.12,.19,.24)); red=mat('RED CAP',(.72,.025,.055)); coat=mat('Charcoal coat',(.22,.25,.27)); skin=mat('Face',(.7,.51,.36)); black=mat('Phone and glasses',(.025,.035,.045)); taxi=mat('Yellow taxi',(.95,.57,.04)); line=mat('Lane marking',(.82,.63,.2))
def box(name,loc,scale,material,parent=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object; o.name=name; o.dimensions=scale; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); o.data.materials.append(material)
 if parent:o.parent=parent
 return o
def ball(name,loc,scale,material,parent=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,location=loc); o=bpy.context.object; o.name=name; o.scale=scale; o.data.materials.append(material)
 if parent:o.parent=parent
 for p in o.data.polygons:p.use_smooth=True
 return o
box('Road',(0,0,-.12),(27,140,.2),road)
for x in [-15,15]:box('Sidewalk',(x,0,-.02),(3,140,.3),stone)
for y in range(-5,6):box('Zebra stripe',(0,y*.95,.008),(23,.48,.025),white)
for y in range(-65,65,5):
 if abs(y)>8:box('Center line',(0,y,.01),(.10,2.6,.02),line)
for side in [-1,1]:
 for idx,y in enumerate(range(-65,66,12)):
  height=16+(idx*7%6)*3
  x=side*22
  box('City block',(x,y,height/2),(11,11,height),stone)
  for z in range(2,height,3):
   for yy in [-3,0,3]:box('Facade window',(x-side*5.53,y+yy,z),(.07,1.15,1.65),glass)
  for z in [1,5,height-.2]:box('Cornice',(x,y,z),(11.45,11.45,.3),stone)
# Hero faces +X. Separate body parts keep movement readable at blocking detail.
hero=bpy.data.objects.new('HERO | walk across +X',None); s.collection.objects.link(hero)
body=box('Long coat',(0,0,1.02),(.43,.64,1.12),coat,hero)
box('White shirt',(.225,0,1.36),(.022,.35,.46),white,hero)
box('Tie',(.245,0,1.36),(.025,.07,.39),black,hero)
ball('Head',(0,0,1.76),(.155,.145,.20),skin,hero)
ball('Cap crown',(0,0,1.91),(.17,.16,.095),red,hero)
box('Cap brim',(.17,0,1.87),(.25,.29,.035),red,hero)
for y in [-.078,.078]:box('Glasses',(.151,y,1.79),(.032,.12,.068),black,hero)
legs=[]; shoes=[]
for y in [-.18,.18]:
 legs.append(box('Trouser leg',(0,y,.37),(.23,.24,.62),coat,hero))
 shoes.append(box('White sneaker',(.06,y,.08),(.4,.26,.15),white,hero))
arm=box('Phone arm',(.25,-.39,1.32),(.43,.18,.19),coat,hero)
hand=ball('Phone hand',(.49,-.39,1.33),(.09,.08,.08),skin,hero)
phone=box('Phone',(.57,-.39,1.40),(.045,.11,.22),black,hero)
box('Other arm',(-.05,.41,1.21),(.21,.19,.58),coat,hero)
# Cars give scale and foreground parallax.
cars=[]
for x,y,col in [(-7,-10,taxi),(7,14,taxi),(-7,34,glass),(7,-35,glass)]:
 root=bpy.data.objects.new('Traffic',None); s.collection.objects.link(root); root.location=(x,y,0)
 box('Car body',(0,0,.62),(1.7,3.9,.72),col,root);box('Car cabin',(0,0,1.16),(1.48,1.9,.54),glass,root)
 for xx in [-.86,.86]:
  for yy in [-1.1,1.1]:ball('Wheel',(xx,yy,.37),(.16,.4,.4),black,root)
 cars.append((root,x,y))
bpy.ops.object.camera_add(); cam=bpy.context.object; cam.name='PREVIS CAMERA'; s.camera=cam; cam.data.sensor_width=36;cam.data.clip_end=500
# Time, camera offset relative to subject, aim height, estimated lens. All creative estimates.
keys=[(0,(-12,-40,65),.9,32),(.55,(-8,-22,32),1,30),(1.25,(0,-4.8,1.9),1,40),(2.25,(.4,-4.6,1.8),1,40),(2.9,(2,-1.5,1.75),1.4,60),(3.85,(2,-1.5,1.75),1.42,60),(4.35,(.7,-2.2,.35),.35,32),(5.55,(.5,-2.2,.35),.32,32),(6.25,(-2.2,-2.6,6.5),.85,32),(7.55,(-2.7,-3,7.5),.9,32),(8.5,(2.1,-1.5,1.85),1.42,60),(10.1,(2,-1.5,1.75),1.45,60),(10.85,(5,-6,2.2),1.0,35),(12.2,(5,-7,2.4),1,35),(13.25,(-10,-18,20),.9,32),(15.167,(-13,-27,34),.9,32)]
def lerp(a,b,u):return a+(b-a)*u
def sample(t):
 for i in range(len(keys)-1):
  a,b=keys[i:i+2]
  if a[0]<=t<=b[0]:
   u=(t-a[0])/(b[0]-a[0]);u=u*u*(3-2*u)
   return tuple(lerp(a[1][j],b[1][j],u) for j in range(3)),lerp(a[2],b[2],u),lerp(a[3],b[3],u)
 return keys[-1][1:]
trajectory=[]
for f in range(1,366):
 t=(f-1)/24
 hx=-4+min(t,6)*.65+max(t-11,0)*.35
 hero.location=(hx,0,0);hero.keyframe_insert('location',frame=f)
 walking=t<6 or t>11
 for i,(leg,shoe) in enumerate(zip(legs,shoes)):
  step=math.sin(t*6+i*math.pi)*.19 if walking else 0
  leg.location.x=step*.5;shoe.location.x=.06+step;shoe.location.z=.08+max(0,step)*.3
  leg.keyframe_insert('location',frame=f);shoe.keyframe_insert('location',frame=f)
 lift=max(0,min(1,(t-6.1)/.9))*max(0,min(1,(8.8-t)/.7))
 for obj,basez in [(hand,1.33),(phone,1.40),(arm,1.32)]:
  obj.location.z=basez+.45*lift;obj.keyframe_insert('location',frame=f)
 for root,x,y in cars:
  root.location.y=y+t*(2.2 if x<0 else -2.4);root.keyframe_insert('location',frame=f)
 off,z,lens=sample(t);cam.location=(hx+off[0],off[1],off[2]);target=Vector((hx,0,z));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=lens
 cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f);cam.data.keyframe_insert('lens',frame=f)
 trajectory.append({'frame':f,'time_s':round(t,4),'camera_xyz':list(cam.location),'target_xyz':list(target),'lens_mm_estimate':lens})
for obj in list(bpy.data.objects)+[cam.data]:
 if obj.animation_data and obj.animation_data.action:
  for fc in obj.animation_data.action.fcurves:
   for kp in fc.keyframe_points:kp.interpolation='LINEAR'
for t,label in [(0,'01 Aerial dive'),(1.25,'02 Side track'),(2.9,'03 Front close'),(4.35,'04 Low shoes'),(6.25,'05 Overhead'),(8.5,'06 Front return'),(10.85,'07 Wide'),(13.25,'08 Aerial exit')]:s.timeline_markers.new(label,frame=int(t*24)+1)
s.render.image_settings.file_format='PNG';s.render.filepath=OUT+'/render/'
s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/camera-previs.blend')
with open(OUT+'/camera-path.json','w') as out:json.dump({'note':'Approximate visual reconstruction, not recovered camera tracking; metres and focal lengths are creative estimates.','fps':24,'duration':365/24,'frames':trajectory},out,indent=2)
# Sparse first render for visual inspection before full animation.
for f in [1,37,73,109,157,205,265,337]:
 s.frame_set(f);s.render.filepath=OUT+f'/frames/{f:04d}.png';bpy.ops.render.render(write_still=True)
