import bpy,json,os
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=OUT+'/replacement-previs.blend')
for o in list(bpy.data.objects):
 if o.name.startswith('CAMERA PATH GUIDE'):bpy.data.objects.remove(o,do_unlink=True)
data=json.load(open(OUT+'/camera-path.json'))
for i,(start,end,label) in enumerate(data['shots'],1):
 rows=[r for r in data['frames'] if r['shot']==i];curve=bpy.data.curves.new('Shot %02d path'%i,'CURVE');curve.dimensions='3D';poly=curve.splines.new('POLY');poly.points.add(len(rows)-1)
 for p,row in zip(poly.points,rows):p.co=(*row['camera_xyz'],1)
 o=bpy.data.objects.new('CAMERA PATH GUIDE | %02d %s'%(i,label),curve);bpy.context.scene.collection.objects.link(o);o.hide_render=True
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/replacement-previs.blend')
