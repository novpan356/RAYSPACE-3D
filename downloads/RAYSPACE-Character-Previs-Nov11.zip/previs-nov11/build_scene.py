import bpy,math,json,os
from mathutils import Vector
OUT=os.path.dirname(os.path.abspath(__file__))
os.makedirs(OUT+'/frames',exist_ok=True);os.makedirs(OUT+'/render',exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=640;s.render.resolution_y=480;s.render.resolution_percentage=100;s.render.fps=30;s.frame_start=1;s.frame_end=480
s.display.shading.light='STUDIO';s.display.shading.color_type='MATERIAL';s.display.shading.show_shadows=True;s.display.shading.show_cavity=True;s.display.shading.cavity_type='BOTH';s.display.shading.background_type='WORLD';s.world.color=(.47,.57,.65);s.view_settings.view_transform='Standard'
def mat(n,c):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);return m
stone=mat('London limestone',(.64,.62,.55));ground=mat('Paving',(.48,.49,.47));navy=mat('Reference NAVY SUIT',(.035,.065,.14));white=mat('Reference WHITE SHIRT',(.88,.9,.88));black=mat('Black shoes',(.025,.035,.04));skin=mat('Skin',(.64,.47,.35));hair=mat('Short black hair',(.018,.023,.027));brown=mat('Woman hair',(.16,.073,.045));burgundy=mat('Burgundy trim',(.23,.04,.065));cream=mat('Cream trim',(.83,.78,.63));blue=mat('Blue handbag',(.025,.065,.16));gold=mat('Gold hardware',(.75,.5,.14));silver=mat('Silver',(.66,.72,.75));red=mat('Red buses and billboard',(.65,.035,.055));glass=mat('Glass',(.06,.14,.19));dark=mat('Fountain',(.08,.095,.085))
def box(n,loc,scale,m,parent=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if parent:o.parent=parent
 return o
def ball(n,loc,scale,m,parent=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=10,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(m)
 if parent:o.parent=parent
 for p in o.data.polygons:p.use_smooth=True
 return o
def cyl(n,loc,r,depth,m,parent=None):
 bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=r,depth=depth,location=loc);o=bpy.context.object;o.name=n;o.data.materials.append(m)
 if parent:o.parent=parent
 return o
def ring(n,loc,r,m,parent=None):
 bpy.ops.mesh.primitive_torus_add(major_segments=20,minor_segments=8,location=loc,major_radius=r,minor_radius=r*.13,rotation=(math.pi/2,0,0));o=bpy.context.object;o.name=n;o.data.materials.append(m)
 if parent:o.parent=parent
 return o
def empty(n):
 o=bpy.data.objects.new(n,None);s.collection.objects.link(o);return o
box('Plaza paving',(0,2,-.12),(50,50,.2),ground)
for x in range(-24,25,2):box('Paving joint',(x,2,-.014),(.017,50,.015),dark)
for y in range(-22,27,2):box('Paving joint',(0,y,-.014),(50,.017,.015),dark)
for side in [-1,1]:
 for i in range(5):
  x=side*(8+i*5);y=14+abs(x)*.12;h=9+i%3*2
  box('London facade',(x,y,h/2),(4.8,6,h),stone)
  for z in [1.3,3.5,6,h-.2]:box('Cornice',(x,y-3,z),(4.9,.3,.2),cream)
  for z in range(2,h,2):
   for xx in [-1.3,0,1.3]:box('Window',(x+xx,y-3.03,z),(.7,.08,1.1),glass)
  if i%2==0:
   cyl('Dome base',(x,y,h+.4),1.5,.8,stone);ball('Dome',(x,y,h+.8),(1.5,1.5,1.2),mat('Dome green'+str(x),(.22,.37,.31)))
# Fountain and stylized winged statue establish screen direction.
for z,r,d in [(.1,3,.25),(.35,2.7,.25),(.62,2.3,.3),(.94,1.7,.35),(1.6,.95,1.1),(3.2,.4,2.1)]:cyl('Fountain',(-4,5,z),r,d,dark)
ball('Winged figure',(-4,5,4.7),(.17,.15,.6),dark)
for sign in [-1,1]:
 wing=ball('Statue wing',(-4+sign*.38,5,5.1),(.18,.10,.75),dark);wing.rotation_euler.y=sign*.65
box('Curved billboard proxy',(5,12,8),(8,.6,4),red)
for x in [-9,9]:
 box('Red double decker',(x,9,1.5),(5.5,2,3),red)
 for z in [1,2.3]:box('Bus windows',(x,7.98,z),(5,.06,.65),glass)
 for xx in [-1.8,1.8]:ball('Bus wheel',(x+xx,8,.35),(.4,.2,.4),black)
# Generic background pedestrians, separate from the two main characters.
for i in range(14):
 x=-10+(i*17%23);y=5+(i*7%9);c=mat('Pedestrian'+str(i),(.17+(i%3)*.06,.19+(i%4)*.04,.20+(i%2)*.08));ball('Background head',(x,y,1.5),(.13,.13,.17),skin);box('Background body',(x,y,.95),(.36,.22,.8),c);box('Background legs',(x,y,.33),(.28,.2,.6),black)
# Actor modeled after provided reference: navy suit, white open collar, short hair, earrings.
man=empty('REFERENCE MAN | navy suit replacement');woman=empty('WOMAN | unchanged blocking proxy')
def person(root,male):
 cloth=navy if male else black
 box('Suit jacket' if male else 'Woman cardigan',(0,0,1.18),(.48,.32,.65),cloth,root)
 if male:
  box('Open white shirt',(0,-.168,1.4),(.26,.025,.38),white,root)
  for sign in [-1,1]:
   lapel=box('Navy lapel',(sign*.14,-.19,1.4),(.10,.025,.35),navy,root);lapel.rotation_euler.y=sign*.28
 else:
  for sign in [-1,1]:
   trim=box('Burgundy and cream trim',(sign*.22,-.18,1.27),(.055,.025,.75),burgundy,root);box('Cream edge',(sign*.185,-.2,1.27),(.018,.02,.75),cream,root)
  ring('Gold brooch',(-.18,-.23,1.39),.04,gold,root)
 legs=[];shoes=[]
 for sign in [-1,1]:
  legs.append(box('Trouser leg' if male else 'Woman leg',(sign*.12,0,.47),(.19,.22,.76),cloth if male else skin,root));shoes.append(box('Black leather shoe',(sign*.12,-.055,.09),(.21,.36,.15),black,root))
 ball('Head',(0,0,1.77),(.16,.14,.21),skin,root)
 for sign in [-1,1]:
  ball('Eye',(sign*.065,-.13,1.80),(.025,.014,.017),black,root);ball('Silver stud earring',(sign*.164,-.01,1.74),(.018,.018,.018),silver,root)
 ball('Nose',(0,-.145,1.76),(.027,.03,.045),skin,root)
 if male:
  ball('Reference short haircut',(0,.005,1.94),(.168,.145,.09),hair,root)
  for i in range(9):
   spike=box('Textured short hair',((i%3-1)*.07,(i//3-1)*.065,1.99),(.06,.06,.06),hair,root);spike.rotation_euler.y=.25
 else:
  ball('Long hair behind head',(0,.095,1.59),(.26,.14,.46),brown,root)
  for sign in [-1,1]:ball('Hair side strand',(sign*.17,.0,1.69),(.07,.085,.3),brown,root)
 arm=empty('Raised speaking hand');arm.parent=root
 box('Speaking forearm',(.27,-.18,1.28),(.17,.38,.17),cloth,arm);ball('Speaking hand',(.27,-.35,1.35),(.075,.07,.10),skin,arm)
 box('Other sleeve',(-.31,0,1.14),(.17,.23,.60),cloth,root);ball('Other hand',(-.31,-.03,.83),(.075,.07,.1),skin,root)
 return legs,shoes,arm
mlegs,mshoes,marm=person(man,True);flegs,fshoes,farm=person(woman,False)
bag=empty('Blue structured handbag');bag.parent=woman
box('Bag body',(0,-.38,.98),(.62,.17,.37),blue,bag)
for sign in [-1,1]:ring('Bag handle',(sign*.12,-.38,1.22),.12,blue,bag)
box('Gold bag clasp',(0,-.478,1.01),(.12,.025,.085),gold,bag)
for x in [-.17,.17]:box('Gold strap',(x,-.477,1.1),(.035,.025,.05),gold,bag)
for x in [.25,.42]:ring('Handcuff',(x,-.37,1.38),.07,silver,marm)
# End card is modeled separately and filmed only in the final shot.
box('Endcard backdrop',(200,1,2),(12,.1,8),black)
for text,z,size,col in [('I HATE HUMAN',3.0,.55,(.9,.57,.77)),('BUT',2.4,.25,(.95,.65,.76)),('HEY THIS IS',1.95,.35,(.96,.78,.31)),('BIRKIN',1.15,.95,(.55,.85,.95))]:
 curve=bpy.data.curves.new('Title','FONT');curve.body=text;curve.align_x='CENTER';curve.size=size;o=bpy.data.objects.new('End card text',curve);s.collection.objects.link(o);o.location=(200,0,z);o.rotation_euler=(math.pi/2,0,0);o.data.materials.append(mat('Title '+text,col))
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='CAMERA | shot-matched visual estimate';s.camera=cam;cam.data.clip_start=.01;cam.data.clip_end=500
stages=[(0,1.8,'Woman reaction'),(1.8,2.8,'Plaza wide'),(2.8,3.7,'Man side track'),(3.7,5.7,'Man close'),(5.7,8.1,'Woman close arc'),(8.1,8.7,'Shoe insert'),(8.7,9.8,'Low medium'),(9.8,11.15,'Brooch detail'),(11.15,12.4,'Handbag detail'),(12.4,14.15,'Two shot'),(14.15,14.75,'Reaction close'),(14.75,16.01,'End card')]
trajectory=[]
def mix(a,b,u):return a+(b-a)*u
for f in range(1,481):
 t=(f-1)/30;idx=next(i for i,(a,b,n) in enumerate(stages) if a<=t<b);a,b,name=stages[idx];u=(t-a)/(b-a);e=u*u*(3-2*u)
 if t<2.8:mx,my=3.3,3
 elif t<3.7:mx,my=mix(3.3,.8,(t-2.8)/.9),mix(3,2,(t-2.8)/.9)
 elif t<11.15:mx,my=.8,2
 elif t<12.4:mx,my=.8,mix(2,.7,(t-11.15)/1.25)
 else:mx,my=.85,.18
 man.location=(mx,my,0);man.rotation_euler.z=-math.pi/2 if t>=12.4 else 0
 woman.rotation_euler.z=min(1,max(0,(t-12.2)/.65))*1.0
 woman.rotation_euler.z+=math.sin(t*5)*.2 if t<1.8 else 0
 man.keyframe_insert('location',frame=f);man.keyframe_insert('rotation_euler',frame=f);woman.keyframe_insert('rotation_euler',frame=f)
 walking=(2.8<t<3.7) or(11.15<t<12.4)
 for i,(leg,shoe) in enumerate(zip(mlegs,mshoes)):
  stride=math.sin(t*9+i*math.pi)*.16 if walking else 0;leg.location.y=stride*.5;shoe.location.y=-.055+stride;leg.keyframe_insert('location',frame=f);shoe.keyframe_insert('location',frame=f)
 marm.location.z=.18 if 3.7<t<5.7 else 0;marm.keyframe_insert('location',frame=f)
 farm.location.z=.2 if 8.7<t<9.8 else 0;farm.keyframe_insert('location',frame=f)
 bag.location.z=min(1,max(0,(t-11.0)/.3))*.18;bag.keyframe_insert('location',frame=f)
 for obj in bpy.data.objects:
  if obj.name.startswith('Handcuff'):obj.hide_render=t<12.4;obj.keyframe_insert('hide_render',frame=f)
 if idx==0:pos=(mix(-.18,.15,e),-2,1.55);target=(0,0,1.43);lens=45
 elif idx==1:pos=(7,-12,7);target=(-2.3,4,1.0);lens=26
 elif idx==2:pos=(mx+3,my-3,1.65);target=(mx,my,1.05);lens=43
 elif idx==3:pos=(mx+mix(.12,-.1,e),my-mix(1.8,1.65,e),1.7);target=(mx,my,1.62);lens=50
 elif idx==4:pos=(mix(-.25,.3,e),-1.6,1.7);target=(0,0,1.58);lens=50
 elif idx==5:pos=(.4,-1.0,.22);target=(0,0,.28);lens=38
 elif idx==6:pos=(.4,-2.1,1.0);target=(0,0,1.45);lens=40
 elif idx==7:pos=(-.16,-.65,1.44);target=(-.18,-.23,1.39);lens=65
 elif idx==8:pos=(.8,-1.6,1.50);target=(0,-.20,1.23);lens=48
 elif idx==9:pos=(-.4,-2.4,1.66);target=(.35,.05,1.43);lens=52
 elif idx==10:pos=(.85*math.sin(1.0),-.85*math.cos(1.0),1.80);target=(0,0,1.78);lens=45
 else:pos=(200,-6.5,2.3);target=(200,0,2.3);lens=40
 cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=lens;cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f);cam.data.keyframe_insert('lens',frame=f)
 trajectory.append({'frame':f,'time_s':round(t,5),'shot':idx+1,'label':name,'camera_xyz':pos,'target_xyz':target,'estimated_focal_mm':lens})
for obj in list(bpy.data.objects)+[cam.data]:
 if obj.animation_data and obj.animation_data.action:
  for fc in obj.animation_data.action.fcurves:
   for p in fc.keyframe_points:p.interpolation='LINEAR'
for a,b,label in stages:s.timeline_markers.new(label,frame=round(a*30)+1)
# Editable camera path guide is visible only in the Blender viewport.
curve=bpy.data.curves.new('Camera path','CURVE');curve.dimensions='3D';poly=curve.splines.new('POLY');poly.points.add(len(trajectory)-1)
for p,row in zip(poly.points,trajectory):p.co=(*row['camera_xyz'],1)
guide=bpy.data.objects.new('CAMERA PATH GUIDE | cut jumps included',curve);s.collection.objects.link(guide);guide.hide_render=True
s.frame_set(1);s.render.image_settings.file_format='PNG';s.render.filepath=OUT+'/render/';bpy.ops.wm.save_as_mainfile(filepath=OUT+'/replacement-previs.blend')
with open(OUT+'/camera-path.json','w') as f:json.dump({'fps':30,'duration':16,'source_aspect':'4:3','note':'Visual estimate, shot cuts preserved. Male is a stylized suit proxy, not a recovered textured human mesh.','shots':stages,'frames':trajectory},f,indent=2)
for frame in [16,67,98,143,205,251,275,310,355,400,432,464]:
 s.frame_set(frame);s.render.filepath=OUT+f'/frames/{frame:04d}.png';bpy.ops.render.render(write_still=True)
