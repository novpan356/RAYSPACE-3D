import bpy,os
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=OUT+'/replacement-previs.blend')
for o in bpy.data.objects:
 if o.name.startswith('Handcuff'):
  o.hide_render=True;o.keyframe_insert('hide_render',frame=1)
  o.hide_render=False;o.keyframe_insert('hide_render',frame=373)
  for fc in o.animation_data.action.fcurves:
   for key in fc.keyframe_points:key.interpolation='CONSTANT'
bpy.context.scene.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/replacement-previs.blend')
