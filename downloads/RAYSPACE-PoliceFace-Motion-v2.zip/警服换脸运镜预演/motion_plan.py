"""视觉拟合预演参数，非原片相机标定结果。坐标：X左右，Y纵深，Z高度。"""
import math
FPS=30;DURATION=16
SHOTS=[
 {'start':0,'end':1.8,'name':'女主反应中近景','f0':45,'f1':45,'o0':0,'o1':0,'action':'小幅横移；不添加变焦；女主回头属于人物动作'},
 {'start':1.8,'end':2.8,'name':'广场高位大全景','f0':26,'f1':26,'o0':0,'o1':0,'action':'硬切高位机位；固定广角；禁止连续升空'},
 {'start':2.8,'end':3.7,'name':'警员侧面跟拍','f0':43,'f1':43,'o0':35,'o1':43,'action':'随男士横向跟拍，叠加8度小弧线观察变化'},
 {'start':3.7,'end':5.7,'name':'警员近景推近变焦','f0':48,'f1':58,'o0':-5,'o1':5,'action':'48到58毫米变焦，机距1.80到1.68米；原片成因不唯一'},
 {'start':5.7,'end':8.1,'name':'女主小弧线环绕','f0':50,'f1':48,'o0':-10,'o1':14,'action':'半径1.8米，24度小弧线；轻微拉宽构图'},
 {'start':8.1,'end':8.7,'name':'鞋部低机位插入','f0':38,'f1':38,'o0':0,'o1':0,'action':'硬切低机位；固定镜头；不把脚步当相机移动'},
 {'start':8.7,'end':9.8,'name':'女主低角度手势','f0':40,'f1':44,'o0':-4,'o1':4,'action':'8度小弧线，40到44毫米变焦；女主抬手独立动画'},
 {'start':9.8,'end':11.15,'name':'胸针细节变焦','f0':65,'f1':70,'o0':0,'o1':0,'action':'硬切微距，65到70毫米轻变焦；固定机位'},
 {'start':11.15,'end':12.4,'name':'手袋前景与警员接近','f0':48,'f1':53,'o0':25,'o1':34,'action':'围绕手袋9度重构图，48到53毫米；男士独立向前走'},
 {'start':12.4,'end':14.15,'name':'双人对话小弧线','f0':50,'f1':54,'o0':-8,'o1':8,'action':'围绕双人中心16度，50到54毫米；男士减速停下转身'},
 {'start':14.15,'end':14.75,'name':'女主反应大特写','f0':45,'f1':45,'o0':0,'o1':0,'action':'硬切近距离反应特写；表情不是相机滚转'},
 {'start':14.75,'end':16.01,'name':'原片文字卡收尾','f0':40,'f1':40,'o0':0,'o1':0,'action':'剪辑到文字卡；不解释为空间飞行'},
]
def ease(u):return u*u*(3-2*u)
def lerp(a,b,u):return a+(b-a)*u
def state(t,zoom_gain=1,orbit_gain=1):
 i=next(i for i,s in enumerate(SHOTS) if s['start']<=t<s['end']);s=SHOTS[i];u=(t-s['start'])/(s['end']-s['start']);e=ease(u)
 lens=s['f0']+(s['f1']-s['f0'])*e*zoom_gain;angle=s['o0']+(s['o1']-s['o0'])*e*orbit_gain;theta=math.radians(angle)
 if t<2.8:man=(2.3,2.5,0)
 elif t<3.7:q=(t-2.8)/.9;man=(lerp(2.3,.8,q),lerp(2.5,2,q),0)
 elif t<11.15:man=(.8,2,0)
 elif t<12.4:q=(t-11.15)/1.25;man=(lerp(.8,.85,q),lerp(2,.35,q),0)
 elif t<12.8:q=ease((t-12.4)/.4);man=(.85,lerp(.35,.18,q),0)
 else:man=(.85,.18,0)
 turn=ease(max(0,min(1,(t-12.4)/.4)));man_yaw=-math.pi/2*turn;woman_yaw=ease(max(0,min(1,(t-12.2)/.65)))*1.0
 woman_head=.35*math.sin(t*5) if t<1.8 else (.15 if t>=12.4 else 0)
 bag_lift=ease(max(0,min(1,(t-11.0)/.3)))*.18
 if i==0:pos=(lerp(-.18,.15,e),-2,1.55);target=(0,0,1.43)
 elif i==1:pos=(7,-12,7);target=(-2.3,4,1)
 elif i==2:r=4.1;pos=(man[0]+math.sin(theta)*r,man[1]-math.cos(theta)*r,1.65);target=(man[0],man[1],1.05)
 elif i==3:r=lerp(1.8,1.68,e);pos=(man[0]+math.sin(theta)*r,man[1]-math.cos(theta)*r,1.72);target=(man[0],man[1],1.68)
 elif i==4:r=1.8;pos=(math.sin(theta)*r,-math.cos(theta)*r,1.7);target=(0,0,1.58)
 elif i==5:pos=(.4,-1,.22);target=(0,0,.28)
 elif i==6:r=2.15;pos=(math.sin(theta)*r,-math.cos(theta)*r,1);target=(0,0,1.45)
 elif i==7:pos=(-.16,-.65,1.44);target=(-.18,-.23,1.39)
 elif i==8:r=1.9;pos=(math.sin(theta)*r,-.2-math.cos(theta)*r,1.55);target=(0,-.2,1.38)
 elif i==9:r=2.5;pos=(.42+math.sin(theta)*r,.08-math.cos(theta)*r,1.68);target=(.42,.08,1.43)
 elif i==10:theta=1.15;pos=(.85*math.sin(theta),-.85*math.cos(theta),1.8);target=(0,0,1.78)
 else:pos=(200,-6.5,2.3);target=(200,0,2.3)
 return {'shot':i+1,'label':s['name'],'camera_xyz':pos,'target_xyz':target,'estimated_focal_mm':lens,'zoom_ratio':lens/s['f0'],'orbit_deg':angle if s['o0']!=s['o1'] else 0,'orbit_total_deg':s['o1']-s['o0'],'man_xyz':man,'man_yaw_rad':man_yaw,'woman_xyz':(0,0,0),'woman_yaw_rad':woman_yaw,'man_head_yaw_rad':(.2 if t>=12.4 else .07*math.sin(t*3) if 3.7<t<5.7 else 0),'woman_head_yaw_rad':woman_head,'bag_lift_m':bag_lift,'cuffs_held':t>=12.4}
def trajectory():
 rows=[]
 for f in range(1,481):
  t=(f-1)/FPS;r=state(t);r.update(frame=f,time_s=t);same=bool(rows and rows[-1]['shot']==r['shot']);r['cut']=not same
  p=rows[-1] if rows else None
  r['camera_speed_m_s']=math.dist(r['camera_xyz'],p['camera_xyz'])*FPS if same else None
  r['man_speed_m_s']=math.dist(r['man_xyz'],p['man_xyz'])*FPS if p else 0
  r['woman_speed_m_s']=0
  for field,out in [('man_yaw_rad','man_turn_speed_deg_s'),('woman_yaw_rad','woman_turn_speed_deg_s'),('woman_head_yaw_rad','woman_head_speed_deg_s')]:r[out]=math.degrees(r[field]-p[field])*FPS if p else 0
  r['bag_speed_m_s']=(r['bag_lift_m']-p['bag_lift_m'])*FPS if p else 0
  r['orbit_speed_deg_s']=(r['orbit_deg']-p['orbit_deg'])*FPS if same else None
  r['zoom_speed_mm_s']=(r['estimated_focal_mm']-p['estimated_focal_mm'])*FPS if same else None
  dx,dy,dz=[b-a for a,b in zip(r['camera_xyz'],r['target_xyz'])];r['view_pitch_deg']=math.degrees(math.atan2(dz,math.hypot(dx,dy)));r['view_yaw_deg']=math.degrees(math.atan2(dy,dx))
  rows.append(r)
 return rows
