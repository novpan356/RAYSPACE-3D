import bpy,json,math,os
from mathutils import Vector
ROOT=os.path.dirname(os.path.abspath(__file__));bpy.ops.wm.open_mainfile(filepath=ROOT+'/police-face-motion.blend');scene=bpy.context.scene;cam=scene.camera;rows=json.load(open(ROOT+'/motion-data.json'))['frames'];man=bpy.data.objects['男性换脸占位 | 原警服保留']
assert not any(n in bpy.data.objects for n in ['Open white shirt','Navy lapel','Suit jacket'])
assert bpy.data.objects.get('POLICE标识') is not None
for row in rows:
 scene.frame_set(row['frame']);assert (cam.location-Vector(row['camera_xyz'])).length<1e-4;assert abs(cam.data.lens-row['estimated_focal_mm'])<1e-4;assert (man.location-Vector(row['man_xyz'])).length<1e-4
 direction=cam.rotation_euler.to_quaternion()@Vector((0,0,-1));expected=(Vector(row['target_xyz'])-cam.location).normalized();assert direction.dot(expected)>.99999
 cuffs=[o for o in bpy.data.objects if o.name.startswith('Handcuff')];assert cuffs and all(o.hide_render==(not row['cuffs_held']) for o in cuffs)
for old,new in [('Reference WHITE SHIRT','原警服白色标识'),('Short black hair','原片黑色长发')]:
 if old in bpy.data.materials:bpy.data.materials[old].name=new
scene.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/police-face-motion.blend');print('480帧实际Blender相机焦距、视角、人物位置、手铐时序及警服保留校验通过')
