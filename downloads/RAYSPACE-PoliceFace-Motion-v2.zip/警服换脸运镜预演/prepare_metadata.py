from pathlib import Path
import json,csv,math
from motion_plan import SHOTS,trajectory
root=Path(__file__).resolve().parent;rows=trajectory()
data=json.loads((root/'motion-data.json').read_text());old=data['frames']
assert len(rows)==len(old)==480
for a,b in zip(rows,old):
 for field in ['camera_xyz','target_xyz','estimated_focal_mm','man_xyz','woman_xyz','man_yaw_rad','woman_yaw_rad','bag_lift_m']:
  av,bv=a[field],b[field]
  if isinstance(av,(list,tuple)):assert all(abs(x-y)<1e-8 for x,y in zip(av,bv)),(field,a['time_s'])
  else:assert abs(av-bv)<1e-8,(field,a['time_s'])
data['frames']=rows;(root/'motion-data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
headers=['镜头','时间秒','内容','焦距变化毫米','zoom倍率','环绕范围度','环绕总角度','环绕平均速度度每秒','环绕峰值速度度每秒','相机平均速度米每秒','相机峰值速度米每秒','男士平均速度米每秒','男士峰值速度米每秒','女主转体峰值速度度每秒','女主转头峰值速度度每秒','视线俯仰角范围度','起始相机XYZ','结束相机XYZ','起始男士XYZ','结束男士XYZ','说明']
with open(root/'中文分镜参数表.csv','w',encoding='utf-8-sig',newline='') as out:
 w=csv.writer(out);w.writerow(headers)
 for i,s in enumerate(SHOTS,1):
  r=[v for v in rows if v['shot']==i];moving=r[1:];dur=s['end']-s['start'];orbit=s['o1']-s['o0'];speeds=[v['camera_speed_m_s'] for v in moving if v['camera_speed_m_s'] is not None];men=[v['man_speed_m_s'] for v in moving]
  w.writerow([i,f"{s['start']:.2f}–{min(16,s['end']):.2f}",s['name'],f"{s['f0']}→{s['f1']}",round(s['f1']/s['f0'],3),f"{s['o0']}→{s['o1']}" if orbit else '无连续环绕',orbit,round(abs(orbit)/dur,3),round(abs(orbit)/dur*1.5,3),round(sum(speeds)/len(speeds),3) if speeds else 0,round(max(speeds or[0]),3),round(sum(men)/len(men),3) if men else 0,round(max(men or[0]),3),round(max(abs(v['woman_turn_speed_deg_s']) for v in moving),3),round(max(abs(v['woman_head_speed_deg_s']) for v in moving),3),f"{min(v['view_pitch_deg'] for v in r):.1f}→{max(v['view_pitch_deg'] for v in r):.1f}",r[0]['camera_xyz'],r[-1]['camera_xyz'],r[0]['man_xyz'],r[-1]['man_xyz'],s['action']+'；数值为预演估计，切点速度不计'])
# Validate actual animation samples, not only printed intentions.
for i,s in enumerate(SHOTS,1):
 r=[v for v in rows if v['shot']==i]
 if s['f0']!=s['f1']:assert max(v['estimated_focal_mm'] for v in r)-min(v['estimated_focal_mm'] for v in r)>abs(s['f1']-s['f0'])*.98
 if s['o0']!=s['o1']:assert abs(r[-1]['orbit_deg']-r[0]['orbit_deg'])>abs(s['o1']-s['o0'])*.98
assert max(v['man_speed_m_s'] for v in rows)<2.0
assert all(v['camera_speed_m_s'] is None for v in rows if v['cut'])
assert all(math.isfinite(x) for v in rows for k in ['camera_xyz','target_xyz','man_xyz'] for x in v[k])
print('480帧运动数据、6段真实变焦、6段小弧线、人物轨迹与切点速度校验通过',flush=True)
