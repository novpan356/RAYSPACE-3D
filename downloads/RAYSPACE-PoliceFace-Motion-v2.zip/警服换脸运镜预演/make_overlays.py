from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,math
root=Path(__file__).resolve().parent;data=json.loads((root/'motion-data.json').read_text());rows=data['frames'];shots=data['shots'];(root/'map').mkdir(exist_ok=True);(root/'stats').mkdir(exist_ok=True)
FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font=lambda n:ImageFont.truetype(FONT,n);small=font(12);mid=font(14);large=font(17)
def point(p):return(160+p[0]*9,230-p[1]*9)
def fmt(n):return '切换不计' if n is None else f'{n:.2f}米/秒'
for r in rows:
 sh=shots[r['shot']-1];im=Image.new('RGB',(320,360),'#15212a');d=ImageDraw.Draw(im);d.text((16,12),f"{r['shot']:02d} / 12  {r['label']}",font=mid,fill='#eed7bc');d.text((16,38),f"焦距 {r['estimated_focal_mm']:.1f}mm · zoom {r['zoom_ratio']:.2f}倍",font=small,fill='#d3e1e7')
 if r['shot']!=12:
  d.rounded_rectangle((15,64,305,330),8,fill='#20313a')
  for x in range(25,306,18):d.line([(x,65),(x,328)],fill='#2a3c43')
  for y in range(70,331,18):d.line([(16,y),(304,y)],fill='#2a3c43')
  for x in [35,80,125,170,215,260]:d.rectangle((x,105,x+26,126),fill='#536069')
  fx,fy=point((-4,5));d.ellipse((fx-18,fy-18,fx+18,fy+18),fill='#53616a');d.text((fx-18,fy-36),'喷泉',font=small,fill='#aabfc9')
  trace=[point(q['camera_xyz']) for q in rows if q['shot']==r['shot']]
  if len(trace)>1:d.line(trace,fill='#f0bc81',width=3)
  maleTrace=[point(q['man_xyz']) for q in rows if 2.8<=q['time_s']<=12.8]
  d.line(maleTrace,fill='#73bcd5',width=2)
  for key,col,yaw in [('woman_xyz','#e695ae',r['woman_yaw_rad']+r['woman_head_yaw_rad']),('man_xyz','#82cfdf',r['man_yaw_rad'])]:
   x,y=point(r[key]);d.ellipse((x-5,y-5,x+5,y+5),fill=col);d.line([(x,y),(x+math.sin(yaw)*12,y+math.cos(yaw)*12)],fill=col,width=2)
  cx,cy=point(r['camera_xyz']);tx,ty=point(r['target_xyz']);a=math.atan2(ty-cy,tx-cx);half=math.atan(36/(2*r['estimated_focal_mm']))
  for delta in [-half,half]:d.line([(cx,cy),(cx+36*math.cos(a+delta),cy+36*math.sin(a+delta))],fill='#f5dab0',width=1)
  d.line([(cx,cy),(tx,ty)],fill='#9d9482',width=1);d.ellipse((cx-4,cy-4,cx+4,cy+4),fill='#ffcd92');d.text((18,306),'橙：相机  蓝：男士  粉：女主',font=small,fill='#cedae1')
 else:d.text((30,158),'文字卡：剪辑切换\n不作为广场空间飞行',font=large,fill='#f1cfaa')
 d.text((17,336),'仅显示本镜头机位轨迹，切点不连接',font=small,fill='#8ea9b7');im.save(root/f"map/{r['frame']:04d}.png")
 footer=Image.new('RGB',(1280,76),'#101a22');draw=ImageDraw.Draw(footer);orbit=f"{r['orbit_deg']:+.1f}° / 共{r['orbit_total_deg']:+.0f}°" if r['orbit_total_deg'] else '无连续环绕'
 draw.text((15,7),f"镜头{r['shot']:02d} {r['label']}  |  {r['time_s']:05.2f}秒  |  焦距 {r['estimated_focal_mm']:.1f}mm  |  zoom {r['zoom_ratio']:.2f}倍  |  环绕 {orbit}",font=large,fill='#edc9a5')
 draw.text((15,42),f"相机速度 {fmt(r['camera_speed_m_s'])}  |  男士速度 {fmt(r['man_speed_m_s'])}  |  女主转头 {r['woman_head_speed_deg_s']:+.1f}°/秒  |  俯仰 {r['view_pitch_deg']:+.1f}°  |  数值为预演设定，非原片标定",font=mid,fill='#b2c5cf');footer.save(root/f"stats/{r['frame']:04d}.png")
banner=Image.new('RGB',(1280,44),'#101a22');d=ImageDraw.Draw(banner)
for x,text in [(15,'原片参考 · 原装扮'),(495,'三维预演 · 仅男性面部替换方向'),(975,'机位与人物俯视轨迹')]:d.text((x,8),text,font=large,fill='#d7e2e7')
banner.save(root/'banner.png')
print('480帧轨迹与动态参数面板已生成')
