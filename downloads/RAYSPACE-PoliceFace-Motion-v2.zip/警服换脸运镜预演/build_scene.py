import bpy,math,json,os
from mathutils import Vector
import sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from motion_plan import SHOTS,state,trajectory
OUT=os.path.dirname(os.path.abspath(__file__))
os.makedirs(OUT+'/frames',exist_ok=True);os.makedirs(OUT+'/render',exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=640;s.render.resolution_y=480;s.render.resolution_percentage=100;s.render.fps=30;s.frame_start=1;s.frame_end=480
s.display.shading.light='STUDIO';s.display.shading.color_type='MATERIAL';s.display.shading.show_shadows=True;s.display.shading.show_cavity=True;s.display.shading.cavity_type='BOTH';s.display.shading.background_type='WORLD';s.world.color=(.47,.57,.65);s.view_settings.view_transform='Standard'
def mat(n,c):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);return m
stone=mat('London limestone',(.64,.62,.55));ground=mat('Paving',(.48,.49,.47));navy=mat('原片深色警服',(.02,.03,.052));white=mat('原警服白色标识',(.88,.9,.88));black=mat('Black shoes',(.025,.035,.04));skin=mat('Skin',(.64,.47,.35));hair=mat('原片黑色长发',(.018,.023,.027));brown=mat('Woman hair',(.16,.073,.045));burgundy=mat('Burgundy trim',(.23,.04,.065));cream=mat('Cream trim',(.83,.78,.63));blue=mat('Blue handbag',(.025,.065,.16));gold=mat('Gold hardware',(.75,.5,.14));silver=mat('Silver',(.66,.72,.75));red=mat('Red buses and billboard',(.65,.035,.055));glass=mat('Glass',(.06,.14,.19));dark=mat('Fountain',(.08,.095,.085))
def box(n,loc,scale,m,parent=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if parent:o.parent=parent
 return o
def ball(n,loc,scale,m,parent=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=10,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(m)
 if parent:o.parent=parent
 for p in o.data.polygons:p.use_smooth=True
 return o
def cyl(n,loc,r,depth,m,parent=None):
 bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=r,depth=depth,location=loc);o=bpy.context.object;o.name=n;o.data.materials.append(m)
 if parent:o.parent=parent
 return o
def ring(n,loc,r,m,parent=None):
 bpy.ops.mesh.primitive_torus_add(major_segments=20,minor_segments=8,location=loc,major_radius=r,minor_radius=r*.13,rotation=(math.pi/2,0,0));o=bpy.context.object;o.name=n;o.data.materials.append(m)
 if parent:o.parent=parent
 return o
def empty(n):
 o=bpy.data.objects.new(n,None);s.collection.objects.link(o);return o
box('Plaza paving',(0,2,-.12),(50,50,.2),ground)
for x in range(-24,25,2):box('Paving joint',(x,2,-.014),(.017,50,.015),dark)
for y in range(-22,27,2):box('Paving joint',(0,y,-.014),(50,.017,.015),dark)
for side in [-1,1]:
 for i in range(5):
  x=side*(8+i*5);y=14+abs(x)*.12;h=9+i%3*2
  box('London facade',(x,y,h/2),(4.8,6,h),stone)
  for z in [1.3,3.5,6,h-.2]:box('Cornice',(x,y-3,z),(4.9,.3,.2),cream)
  for z in range(2,h,2):
   for xx in [-1.3,0,1.3]:box('Window',(x+xx,y-3.03,z),(.7,.08,1.1),glass)
  if i%2==0:
   cyl('Dome base',(x,y,h+.4),1.5,.8,stone);ball('Dome',(x,y,h+.8),(1.5,1.5,1.2),mat('Dome green'+str(x),(.22,.37,.31)))
# Fountain and stylized winged statue establish screen direction.
for z,r,d in [(.1,3,.25),(.35,2.7,.25),(.62,2.3,.3),(.94,1.7,.35),(1.6,.95,1.1),(3.2,.4,2.1)]:cyl('Fountain',(-4,5,z),r,d,dark)
ball('Winged figure',(-4,5,4.7),(.17,.15,.6),dark)
for sign in [-1,1]:
 wing=ball('Statue wing',(-4+sign*.38,5,5.1),(.18,.10,.75),dark);wing.rotation_euler.y=sign*.65
box('Curved billboard proxy',(5,12,8),(8,.6,4),red)
for x in [-9,9]:
 box('Red double decker',(x,9,1.5),(5.5,2,3),red)
 for z in [1,2.3]:box('Bus windows',(x,7.98,z),(5,.06,.65),glass)
 for xx in [-1.8,1.8]:ball('Bus wheel',(x+xx,8,.35),(.4,.2,.4),black)
# Generic background pedestrians, separate from the two main characters.
for i in range(14):
 x=-10+(i*17%23);y=5+(i*7%9);c=mat('Pedestrian'+str(i),(.17+(i%3)*.06,.19+(i%4)*.04,.20+(i%2)*.08));ball('Background head',(x,y,1.5),(.13,.13,.17),skin);box('Background body',(x,y,.95),(.36,.22,.8),c);box('Background legs',(x,y,.33),(.28,.2,.6),black)
# 面部身份替换方向占位；服装、长发、对讲机和装备按原片警服保留。
man=empty('男性换脸占位 | 原警服保留');woman=empty('WOMAN | unchanged blocking proxy')
def person(root,male):
 cloth=navy if male else black
 box('原警服外套' if male else 'Woman cardigan',(0,0,1.18),(.48,.32,.65),cloth,root)
 if male:
  box('原战术背心',(0,-.2,1.21),(.46,.09,.48),navy,root)
  box('原高领',(0,0,1.57),(.26,.28,.16),navy,root)
  patch=mat('原蓝色警服标识',(.025,.12,.32));box('原POLICE胸贴',(0,-.254,1.28),(.34,.018,.1),patch,root)
  curve=bpy.data.curves.new('原警服英文标识','FONT');curve.body='POLICE';curve.size=.072;curve.align_x='CENTER';obj=bpy.data.objects.new('POLICE标识',curve);s.collection.objects.link(obj);obj.parent=root;obj.location=(0,-.266,1.25);obj.rotation_euler=(math.pi/2,0,0);curve.materials.append(white)
  box('原装备腰带',(0,0,.92),(.53,.36,.09),black,root)
  for sign in [-1,1]:
   box('原肩章',(sign*.27,0,1.53),(.16,.23,.04),black,root)
   box('原袖章',(sign*.335,-.07,1.32),(.03,.12,.12),patch,root)
   box('原装备袋',(sign*.22,-.21,1.05),(.10,.10,.12),black,root)
  box('原对讲机',(.15,-.29,1.45),(.1,.06,.16),black,root);cyl('对讲机天线',(.15,-.29,1.60),.012,.18,black,root)
 else:
  for sign in [-1,1]:
   trim=box('Burgundy and cream trim',(sign*.22,-.18,1.27),(.055,.025,.75),burgundy,root);box('Cream edge',(sign*.185,-.2,1.27),(.018,.02,.75),cream,root)
  ring('Gold brooch',(-.18,-.23,1.39),.04,gold,root)
 legs=[];shoes=[]
 for sign in [-1,1]:
  legs.append(box('Trouser leg' if male else 'Woman leg',(sign*.12,0,.47),(.19,.22,.76),cloth if male else skin,root));shoes.append(box('Black leather shoe',(sign*.12,-.055,.09),(.21,.36,.15),black,root))
 ball('Head',(0,0,1.77),(.16,.14,.21),skin,root)
 for sign in [-1,1]:
  ball('Eye',(sign*.065,-.13,1.80),(.025,.014,.017),black,root);ball('原耳部细节',(sign*.164,-.01,1.74),(.014,.014,.014),silver if not male else skin,root)
 ball('Nose',(0,-.145,1.76),(.027,.03,.045),skin,root)
 if male:
  ball('原片黑色偏长发顶部',(0,.015,1.96),(.18,.155,.105),hair,root)
  ball('原片后脑长发',(0,.115,1.77),(.18,.08,.27),hair,root)
  for sign in [-1,1]:ball('原片侧面长发',(sign*.145,.035,1.82),(.05,.08,.19),hair,root)
 else:
  ball('Long hair behind head',(0,.095,1.59),(.26,.14,.46),brown,root)
  for sign in [-1,1]:ball('Hair side strand',(sign*.17,.0,1.69),(.07,.085,.3),brown,root)
 arm=empty('Raised speaking hand');arm.parent=root
 box('Speaking forearm',(.27,-.18,1.28),(.17,.38,.17),cloth,arm);ball('Speaking hand',(.27,-.35,1.35),(.075,.07,.10),skin,arm)
 box('Other sleeve',(-.31,0,1.14),(.17,.23,.60),cloth,root);ball('Other hand',(-.31,-.03,.83),(.075,.07,.1),skin,root)
 return legs,shoes,arm
mlegs,mshoes,marm=person(man,True);flegs,fshoes,farm=person(woman,False)
def head_control(root):
 h=empty('头部动作控制');h.parent=root
 for obj in list(root.children):
  if obj is not h and obj.name.startswith(('Head','Eye','Nose','原片黑色','原片后脑','原片侧面','Long hair','Hair side','原耳部')):obj.parent=h
 return h
mhead=head_control(man);fhead=head_control(woman)

bag=empty('Blue structured handbag');bag.parent=woman
box('Bag body',(0,-.38,.98),(.62,.17,.37),blue,bag)
for sign in [-1,1]:ring('Bag handle',(sign*.12,-.38,1.22),.12,blue,bag)
box('Gold bag clasp',(0,-.478,1.01),(.12,.025,.085),gold,bag)
for x in [-.17,.17]:box('Gold strap',(x,-.477,1.1),(.035,.025,.05),gold,bag)
for x in [.25,.42]:ring('Handcuff',(x,-.37,1.38),.07,silver,marm)
# End card is modeled separately and filmed only in the final shot.
box('Endcard backdrop',(200,1,2),(12,.1,8),black)
for text,z,size,col in [('I HATE HUMAN',3.0,.55,(.9,.57,.77)),('BUT',2.4,.25,(.95,.65,.76)),('HEY THIS IS',1.95,.35,(.96,.78,.31)),('BIRKIN',1.15,.95,(.55,.85,.95))]:
 curve=bpy.data.curves.new('Title','FONT');curve.body=text;curve.align_x='CENTER';curve.size=size;o=bpy.data.objects.new('End card text',curve);s.collection.objects.link(o);o.location=(200,0,z);o.rotation_euler=(math.pi/2,0,0);o.data.materials.append(mat('Title '+text,col))
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='CAMERA | shot-matched visual estimate';s.camera=cam;cam.data.clip_start=.01;cam.data.clip_end=500
stages=[(v['start'],v['end'],v['name']) for v in SHOTS]
trajectory_rows=trajectory()
for row in trajectory_rows:
 f=row['frame'];t=row['time_s'];idx=row['shot']-1
 man.location=row['man_xyz'];man.rotation_euler.z=row['man_yaw_rad'];woman.location=row['woman_xyz'];woman.rotation_euler.z=row['woman_yaw_rad']
 mhead.rotation_euler.z=.2 if t>=12.4 else (.07*math.sin(t*3) if 3.7<=t<5.7 else 0);fhead.rotation_euler.z=row['woman_head_yaw_rad']
 for obj in [man,woman,mhead,fhead]:obj.keyframe_insert('location',frame=f);obj.keyframe_insert('rotation_euler',frame=f)
 walking=(2.8<t<3.7) or(11.15<t<12.8)
 for i,(leg,shoe) in enumerate(zip(mlegs,mshoes)):
  stride=math.sin(t*9+i*math.pi)*.14 if walking else 0;leg.location.y=stride*.5;shoe.location.y=-.055+stride;leg.keyframe_insert('location',frame=f);shoe.keyframe_insert('location',frame=f)
 marm.location.z=.18 if 3.7<t<5.7 else 0;marm.keyframe_insert('location',frame=f)
 farm.location.z=.2 if 8.7<t<9.8 else 0;farm.keyframe_insert('location',frame=f)
 bag.location.z=row['bag_lift_m'];bag.keyframe_insert('location',frame=f)
 for obj in bpy.data.objects:
  if obj.name.startswith('Handcuff'):obj.hide_render=not row['cuffs_held'];obj.keyframe_insert('hide_render',frame=f)
 cam.location=row['camera_xyz'];cam.rotation_euler=(Vector(row['target_xyz'])-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=row['estimated_focal_mm'];cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f);cam.data.keyframe_insert('lens',frame=f)
for obj in list(bpy.data.objects)+[cam.data]:
 if obj.animation_data and obj.animation_data.action:
  for fc in obj.animation_data.action.fcurves:
   for p in fc.keyframe_points:p.interpolation='LINEAR'
for a,b,label in stages:s.timeline_markers.new(label,frame=math.ceil(a*30)+1)
# 分镜独立路径与人物轨迹：切点不连接成相机飞行。
for idx,shot in enumerate(SHOTS,1):
 rows=[r for r in trajectory_rows if r['shot']==idx]
 for field,name in [('camera_xyz','相机轨迹'),('man_xyz','男士轨迹')]:
  curve=bpy.data.curves.new(name,'CURVE');curve.dimensions='3D';poly=curve.splines.new('POLY');poly.points.add(len(rows)-1)
  for point,row in zip(poly.points,rows):point.co=(*row[field],1)
  guide=bpy.data.objects.new('%02d %s %s'%(idx,shot['name'],name),curve);s.collection.objects.link(guide);guide.hide_render=True
s.frame_set(1);s.render.image_settings.file_format='PNG';s.render.filepath=OUT+'/render/';bpy.ops.wm.save_as_mainfile(filepath=OUT+'/police-face-motion.blend')
with open(OUT+'/motion-data.json','w') as out:json.dump({'fps':30,'duration':16,'aspect':'4:3','note':'全部焦距、角度和米制速度是预演拟合参数，不是原片标定结果。切点不计算相机跨场景速度。仅换面部，原警服与发型保留。','shots':SHOTS,'frames':trajectory_rows},out,ensure_ascii=False,indent=2)
for frame in [16,67,98,143,205,251,275,310,355,400,432,464]:
 s.frame_set(frame);s.render.filepath=OUT+f'/frames/{frame:04d}.png';bpy.ops.render.render(write_still=True)
